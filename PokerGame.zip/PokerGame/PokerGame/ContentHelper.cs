﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGame
{
   public class ContentHelper
    {      
        /// <summary>
        /// 当前操作人员
        /// </summary>
        public Person NowPerson { get; set; }

        /// <summary>
        /// 第一个操作人员
        /// </summary>
        public Person FirstPerson { get; set; }

    }
}
