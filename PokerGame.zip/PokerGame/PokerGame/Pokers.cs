﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokerGame
{
    public partial class Pokers : UserControl
    {
        public delegate void GetClick(Pokers sender,EventArgs e);
        public event GetClick GetClickLine;

        /// <summary>
        /// 设置当前的行数
        /// </summary>
        public int Line { get; set; }

        /// <summary>
        /// 设置当前行的按钮个数
        /// </summary>
        public int PokerNumber { get; set; }

        /// <summary>
        /// 是否选择行数冲突
        /// </summary>
        public bool IsExchangeLine { get; set; }

       /// <summary>
       /// 剩下未选择的火柴数
       /// </summary>
        public int LastPokerNumber
        {
            get
            {
                int number = 0;
                foreach (var item in this.Controls)
                {
                    if(item is Button)
                    {
                        Button btn = (Button)item;
                        if(btn.Enabled==true)
                        {
                            number++;
                        }
                    }
                }
                return number;
            }
        }
        public Pokers()
        {
            InitializeComponent();
        }

        public  Pokers(int Line,int PokerNumber)
        {
            InitializeComponent();
            this.Line = Line;
            this.PokerNumber = PokerNumber;
            this.IsExchangeLine = false;
        }

        private void AddPokers()
        {
            if(this.PokerNumber>0)
            {
                for (int i = 0; i < PokerNumber; i++)
                {
                    Button poker = new Button();
                    poker.Text = string.Format("{0}行{1}列", this.Line, i+1);
                    poker.BackColor = Color.Red;
                    poker.Left = poker.Width * i;
                    poker.Click += Poker_Click;
                    this.Controls.Add(poker);
                }
            }
        }

        /// <summary>
        /// 每个火柴的点击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Poker_Click(object sender, EventArgs e)
        {
            if (this.GetClickLine != null)
            {
                this.GetClickLine(this, new EventArgs());
            }
            Button btn = (Button)sender;
            if (!IsExchangeLine)
            {
                btn.Enabled = false;
                btn.BackColor = Color.Gray;
            }           
        }

        /// <summary>
        /// 重置
        /// </summary>
        public　void Reset()
        {
            foreach (var item in this.Controls)
            {
                if(item is Button)
                {
                    Button btn = (Button)item;
                    btn.Enabled = true;
                    btn.BackColor = Color.Red;
                }
            }
        }

        private void Pokers_Load(object sender, EventArgs e)
        {
            this.AddPokers();
        }

        public void SetAllNoEnable()
        {
            foreach (var item in this.Controls)
            {
                if (item is Button)
                {
                    Button btn = (Button)item;
                    btn.Enabled = false; ;
                    btn.BackColor = Color.Gray;
                }
            }
        }
    }
}
