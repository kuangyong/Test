﻿namespace PokerGame
{
    partial class FrMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnA = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.lbfirstPerson = new System.Windows.Forms.Label();
            this.btnReplay = new System.Windows.Forms.Button();
            this.lbResult = new System.Windows.Forms.Label();
            this.lbNowPerson = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(228, 52);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(227, 24);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(227, 24);
            this.toolStripMenuItem2.Text = "toolStripMenuItem2";
            // 
            // btnA
            // 
            this.btnA.Location = new System.Drawing.Point(153, 15);
            this.btnA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(100, 29);
            this.btnA.TabIndex = 2;
            this.btnA.Text = "玩家甲";
            this.btnA.UseVisualStyleBackColor = true;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // btnB
            // 
            this.btnB.Location = new System.Drawing.Point(261, 15);
            this.btnB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(100, 29);
            this.btnB.TabIndex = 3;
            this.btnB.Text = "玩家乙";
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.btnB_Click);
            // 
            // lbfirstPerson
            // 
            this.lbfirstPerson.AutoSize = true;
            this.lbfirstPerson.Location = new System.Drawing.Point(15, 21);
            this.lbfirstPerson.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbfirstPerson.Name = "lbfirstPerson";
            this.lbfirstPerson.Size = new System.Drawing.Size(67, 15);
            this.lbfirstPerson.TabIndex = 4;
            this.lbfirstPerson.Text = "谁先玩：";
            // 
            // btnReplay
            // 
            this.btnReplay.Location = new System.Drawing.Point(601, 15);
            this.btnReplay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReplay.Name = "btnReplay";
            this.btnReplay.Size = new System.Drawing.Size(100, 29);
            this.btnReplay.TabIndex = 5;
            this.btnReplay.Text = "重玩";
            this.btnReplay.UseVisualStyleBackColor = true;
            this.btnReplay.Click += new System.EventHandler(this.btnReplay_Click);
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Location = new System.Drawing.Point(268, 76);
            this.lbResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(52, 15);
            this.lbResult.TabIndex = 6;
            this.lbResult.Text = "结果：";
            // 
            // lbNowPerson
            // 
            this.lbNowPerson.AutoSize = true;
            this.lbNowPerson.Location = new System.Drawing.Point(8, 76);
            this.lbNowPerson.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbNowPerson.Name = "lbNowPerson";
            this.lbNowPerson.Size = new System.Drawing.Size(82, 15);
            this.lbNowPerson.TabIndex = 7;
            this.lbNowPerson.Text = "当前玩家：";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(493, 15);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 29);
            this.btnStart.TabIndex = 8;
            this.btnStart.Text = "开始";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(919, 496);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(100, 29);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "确定";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(11, 110);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1040, 379);
            this.panel1.TabIndex = 10;
            // 
            // FrMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lbNowPerson);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.btnReplay);
            this.Controls.Add(this.lbfirstPerson);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnA);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "FrMain";
            this.Text = "火柴小游戏";
            this.Load += new System.EventHandler(this.FrMain_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Label lbfirstPerson;
        private System.Windows.Forms.Button btnReplay;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbNowPerson;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Panel panel1;
    }
}

