﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokerGame
{
    public partial class FrMain : Form
    {
        ContentHelper content;
        List<Person> persons;
        public int LastPokersNumber = 0;
        public FrMain()
        {
            InitializeComponent();
            content = new ContentHelper();
           
        }
        private void FrMain_Load(object sender, EventArgs e)
        {
            this.btnReplay.Enabled = false;
            AddPerson();
            AddPokers();
        }

        /// <summary>
        /// 添加火柴
        /// </summary>
        public void AddPokers()
        {
            //添加第一行
            Pokers pokers = new Pokers(1, 3);
            pokers.Height = 50;
            pokers.Width = this.panel1.Width;
            pokers.GetClickLine += Pokers_GetClickLine;
            this.panel1.Controls.Add(pokers);
            //添加第二行
            Pokers pokers2 = new Pokers(2, 5);
            pokers2.Height = 50;
            pokers2.Width = this.panel1.Width;
            pokers2.Top = pokers.Height + pokers.Top;
            pokers2.GetClickLine+= Pokers_GetClickLine;
            this.panel1.Controls.Add(pokers2);
            //添加第三行
            Pokers pokers3 = new Pokers(3, 7);
            pokers3.Height = 50;
            pokers3.Width = this.panel1.Width;
            pokers3.Top = pokers2.Height + pokers2.Top;
            pokers3.GetClickLine+= Pokers_GetClickLine;
            this.panel1.Controls.Add(pokers3);
            LastPokersNumber = pokers.LastPokerNumber + pokers2.LastPokerNumber + pokers3.LastPokerNumber;
            SetAllNoEnable(false);
        }

       

        /// <summary>
        /// 添加人员
        /// </summary>
        private void AddPerson()
        {
            persons = new List<Person>();
            Person personA = new Person
            {
                ID = 1,
                Name = "玩家甲",
                Line = 0
            };
            Person personB = new Person
            {
                ID = 2,
                Name = "玩家乙",
                Line = 0
            };
            persons.Add(personA);
            persons.Add(personB);     
        }
      

        #region 点击事件
        /// <summary>
        /// 玩家甲先玩
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnA_Click(object sender, EventArgs e)
        {
            if(content!=null)
            {
                content.FirstPerson = persons.Where(a => a.ID == 1).ToList().FirstOrDefault();
                content.NowPerson = content.FirstPerson;
                this.btnA.Enabled = false;
                this.btnB.Enabled = false;
                setMsg();
                this.btnReplay.Enabled = true;
            }
          
        }

        /// <summary>
        /// 设置玩家乙先玩
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnB_Click(object sender, EventArgs e)
        {
            if (content != null)
            {
                content.FirstPerson = persons.Where(a => a.ID == 2).ToList().FirstOrDefault();
                content.NowPerson = content.FirstPerson;
                this.btnA.Enabled = false;
                this.btnB.Enabled = false;
                setMsg();
                this.btnReplay.Enabled = true;
            }
           
        }
     

        /// <summary>
        /// 确定操作步骤
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            //判断有没有选择
            int lastNUmber = 0;
            foreach (var item in this.panel1.Controls)
            {
                if(item is Pokers)
                {
                    Pokers poker = (Pokers)item;
                    lastNUmber += poker.LastPokerNumber;
                }
            }
            if(lastNUmber==this.LastPokersNumber)
            {
                MessageBox.Show(string.Format("{0}:必须选择至少一个！",content.NowPerson.Name));
                return;
            }
            //判断是否是最后一个,游戏结束
            if(lastNUmber==0)
            {
                MessageBox.Show(string.Format("{0}：你输了！游戏结束", content.NowPerson.Name));
                this.lbResult.Text = string.Format("结果：{0}输了", content.NowPerson.Name);
                return;
            }
            //继续游戏
            ClearPersonLine();
            Person person = this.persons.Where(a => a.ID != content.NowPerson.ID).ToList().FirstOrDefault();
            this.content.NowPerson = person;
            this.LastPokersNumber = lastNUmber;
            setMsg();
        }

        /// <summary>
        /// 开始游戏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStart_Click(object sender, EventArgs e)
        {
            if(content.FirstPerson==null)
            {
                MessageBox.Show("请先确定谁先玩！");
                return;
            }
            // AddPokers();
            SetAllNoEnable(true);
            this.btnStart.Enabled = false;
            this.btnReplay.Enabled = true;
        }
        /// <summary>
        /// 重玩
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReplay_Click(object sender, EventArgs e)
        {
            this.btnA.Enabled = true;
            this.btnB.Enabled = true;
            this.btnStart.Enabled = true;
            this.btnOK.Enabled = false;
            this.btnReplay.Enabled = false;
            this.lbfirstPerson.Text = "谁先玩：";
            this.lbNowPerson.Text = "当前玩家：";
            this.lbResult.Text = "结果：";
            this.content.FirstPerson = null;
            this.content.NowPerson = null;
            SetAllNoEnable(false);
            ClearPersonLine();
        }

        #endregion

        #region 私有帮助方法

        /// <summary>
        /// 判断是否跨行操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Pokers_GetClickLine(Pokers sender, EventArgs e)
        {         
            if (content.NowPerson.Line == 0)
            {
                content.NowPerson.Line = sender.Line;
            }
            if (content.NowPerson.Line > 0 && content.NowPerson.Line != sender.Line)
            {
                sender.IsExchangeLine = true;
                MessageBox.Show("不能跨行操作");
            }
            else
            {
                sender.IsExchangeLine = false;
            }
        }
        /// <summary>
        /// 清空用户当前操作行数
        /// </summary>
        private void ClearPersonLine()
        {
            foreach (var item in persons)
            {
                item.Line = 0;
            }
        }

        /// <summary>
        /// 设置信息
        /// </summary>
        private void setMsg()
        {
            this.lbfirstPerson.Text = string.Format("谁先玩：{0}", this.content.FirstPerson.Name);
            lbNowPerson.Text = string.Format("当前玩家：{0}", content.NowPerson.Name);
        }

        /// <summary>
        /// 设置火柴是否可用
        /// </summary>
        /// <param name="enable"></param>
        private void SetAllNoEnable(bool enable)
        {
            int lastNumer = 0;
            foreach (var item in this.panel1.Controls)
            {
                if(item is Pokers)
                {
                    Pokers poker = (Pokers)item;
                    if(enable)
                    {
                        poker.Reset();
                        this.btnOK.Enabled = true;
                        lastNumer += poker.LastPokerNumber;
                    }
                    else
                    {
                        poker.SetAllNoEnable();
                        this.btnOK.Enabled = false;
                    }
                   
                }
            }
            if(enable)
            {
                this.LastPokersNumber = lastNumer;
            }
        }


        #endregion
     
    }
}
